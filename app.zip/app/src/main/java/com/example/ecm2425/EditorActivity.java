package com.example.ecm2425;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.HashSet;

public class EditorActivity extends AppCompatActivity {
    //Variables Declared static so they can be accessed from different methods
    static ArrayList<String> cities = new ArrayList<>();
    static ArrayAdapter arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Lists all the cities, with additional info(Temperature and condition), the user has saved
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);
        ListView listView = (ListView) findViewById(R.id.listView);

        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("com.example.ecm2425", Context.MODE_PRIVATE);
        HashSet<String> set = (HashSet<String>) sharedPreferences.getStringSet("cities", null);
        if (set == null) {
            cities = new ArrayList<>();
        } else {
            cities = new ArrayList(set);
        }
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, cities);

        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            //If the user selects one of the cities they will return to the MainActivity with the expanded details
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                String city = cities.get(i).split(" ")[0];
                intent.putExtra("city", city);
                intent.putExtra("city", city);
                startActivity(intent);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            //This allows the user to delete cities from memory
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                final int itemNum = i;
                new AlertDialog.Builder(EditorActivity.this).setIcon(android.R.drawable.ic_dialog_alert).setTitle("Are you sure?").setMessage("Do you want to delete this note?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        cities.remove(itemNum);
                        arrayAdapter.notifyDataSetChanged();
                        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("com.example.ecm2425", Context.MODE_PRIVATE);
                        HashSet<String> set = new HashSet(EditorActivity.cities);
                        sharedPreferences.edit().clear();
                        sharedPreferences.edit().putStringSet("cities", set).commit();

                    }
                }).setNegativeButton("no", null).show();
                return true;
            }
        });
    }

}