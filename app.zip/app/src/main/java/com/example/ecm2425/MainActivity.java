package com.example.ecm2425;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;

public class MainActivity extends AppCompatActivity {
    //Declaring every variable that needs to be accessible in multiple functions
    private TextView cityNameXML, temperatureXML, conditionXML;
    private RecyclerView weatherXM;
    private TextInputEditText cityInput;
    private ImageView background, icon, search;
    private String cityName;
    private ArrayList<WeatherModel> weatherModelArrayList;
    private WeatherAdapter weatherAdapter;
    private HashSet<String> set;
    private TextView linkTextView;
    static ArrayList<String> cities;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //creates option menu so that user can add a city to permanent storage or to view the cities they have in memory
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.add_note_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        if (item.getItemId() == R.id.view_cities) {
            //If the user wishes to view the cities this will start an explicit intent and start the EditorActivity

            Intent intent = new Intent(getApplicationContext(), EditorActivity.class);

            startActivity(intent);

            return true;
        } else if (item.getItemId() == R.id.add_city) {
            /*
            If the user selects to add a city to the permanent storage. A HashSet will be created which contains all cities already in the memory(This is done by SharedPreferences)
            and adds the city the user has selected, with some minimal data, to the arrayList. This is then converted back into the HashSet and commited to permanent memory
             */
            SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("com.example.ecm2425", Context.MODE_PRIVATE);
            set = (HashSet<String>) sharedPreferences.getStringSet("cities", null);
            cities = new ArrayList(set);
            cities.add(cityName + "        " + temperatureXML.getText() + "        " + conditionXML.getText());

            Log.d("AddCity", String.valueOf(cities));
            sharedPreferences.edit().clear();
            set = new HashSet(MainActivity.cities);
            sharedPreferences.edit().putStringSet("cities", set).commit();
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //All the variables that were declared are now initialized
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        Configuration config = getResources().getConfiguration();
        setContentView(R.layout.activity_main);
        cityNameXML = findViewById(R.id.idCityName);
        temperatureXML = findViewById(R.id.idTemperature);
        conditionXML = findViewById(R.id.idTVCondition);
        weatherXM= findViewById(R.id.idWeather);
        cityInput = findViewById(R.id.idInputCityName);
        background = findViewById(R.id.idBack);
        icon = findViewById(R.id.idConditionIcon);
        search = findViewById(R.id.idSearch);
        linkTextView = findViewById(R.id.idHolder);
        weatherModelArrayList = new ArrayList<>();
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        //Checks if the user is connected to the internet
        boolean connected = cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
        if (connected == true) {
            weatherAdapter = new WeatherAdapter(this, weatherModelArrayList);
            weatherXM.setAdapter(weatherAdapter);
            SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("com.example.ecm2425", Context.MODE_PRIVATE);
            set = (HashSet<String>) sharedPreferences.getStringSet("cities", null);
            cities = new ArrayList(set);
            Intent intent = getIntent();
            if (!set.isEmpty() && !intent.hasExtra("city")) {
                //If the set is not empty and there was no extra intent(the activity was called from the EditorActivity), then we select a city in memory and call the WeatherInfo method
                String[] cityArray = cities.get(0).split(" ");
                cityName = cityArray[0];
                //Adititonal information is added to the memory for user benefit in EditorActivity
                getWeatherInfo(cityName);
            } else if (intent.hasExtra("city")) {
                //If the intent has extra data with a variable name city, the citie's name will be used to call the getWeatherInfo function
                cityName = intent.getStringExtra("city");
                getWeatherInfo(cityName);
            }

            search.setOnClickListener(new View.OnClickListener() {
                //On click of the search icon, the text from the text field is passed on  to the getWeatherInfo
                @Override
                public void onClick(View view) {
                    cityName = cityInput.getText().toString();
                    if (cityName.isEmpty()) {
                        Toast.makeText(MainActivity.this, "Please enter city Name", Toast.LENGTH_SHORT).show();
                    } else {
                        cityNameXML.setText(cityName);
                        getWeatherInfo(cityName);
                    }
                }
            });
            linkTextView.setOnClickListener(new View.OnClickListener() {
                //On click of the "where we get our data" text view, and implicit intent is called to open the link in a web browser
                @Override
                public void onClick(View view) {
                    Intent implicitIntent = new Intent(Intent.ACTION_VIEW);
                    implicitIntent.setData(Uri.parse("https://www.weatherapi.com"));
                    startActivity(implicitIntent);
                }
            });
        } else {
            //if the user is not connected to the internet, a message is displayed to inform the user
            temperatureXML.setText("You are not connected to the internet and therefore we cannot supply the data you are looking for");
        }


    }

    private void getWeatherInfo(String cityName) {
        //This method gets the JSON object form weatherapi.com using the volley library and processes the data so the user can view it
        String url = "https://api.weatherapi.com/v1/forecast.json?key=63fc9e7444814a7b85b165701221503&q=" + cityName + "&days=1&aqi=yes&alerts=yes";
        cityNameXML.setText(cityName);
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                weatherModelArrayList.clear();

                try {
                    String temperature = response.getJSONObject("current").getString("temp_c");
                    temperatureXML.setText(temperature + "ºC");
                    int isDay = response.getJSONObject("current").getInt("is_day");
                    String condition = response.getJSONObject("current").getJSONObject("condition").getString("text");
                    String conditionIcon = response.getJSONObject("current").getJSONObject("condition").getString("icon");
                    Picasso.get().load("https:".concat(conditionIcon)).into(icon);
                    icon.setVisibility(View.VISIBLE);
                    conditionXML.setText(condition);
                    conditionXML.setVisibility(View.VISIBLE);

                    if (isDay == 1) {
                        Picasso.get().load("https://images.unsplash.com/photo-1566321343730-237ec35e53f3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1631&q=80").into(background);
                    } else {
                        Picasso.get().load("https://images.unsplash.com/photo-1435224654926-ecc9f7fa028c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80").into(background);
                    }

                    JSONObject forecastObj = response.getJSONObject("forecast");
                    JSONObject forcastO = forecastObj.getJSONArray("forecastday").getJSONObject(0);
                    JSONArray hourArray = forcastO.getJSONArray("hour");

                    for (int i = 0; i < hourArray.length(); i++) {
                        JSONObject hourObj = hourArray.getJSONObject(i);
                        String time = hourObj.getString("time");
                        String temper = hourObj.getString("temp_c");
                        String img = hourObj.getJSONObject("condition").getString("icon");
                        String wind = hourObj.getString("wind_kph");
                        weatherModelArrayList.add(new WeatherModel(time, temper, img, wind));
                        weatherAdapter.notifyDataSetChanged();

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //If there is an error, the user will get a Toast message requesting a valid input
                Toast.makeText(MainActivity.this, "Please enter valid city name..", Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(jsonObjectRequest);

    }

}